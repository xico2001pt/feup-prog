#include <vector>

#ifndef oware
#define oware

// Color Constants
#define RESET 7
#define BLUE 9
#define RED 12
#define YELLOW 14
const short COLORS[2] = { BLUE, RED }; // Assign a color to each player

// Board Constants
#define HOLES_PER_ROW 6
#define ROWS 2
#define MOVE_SEED_TIME 500 // Time in milliseconds to simulate the move of a seed
#define DECISION_TIME 2100 // Time in milliseconds to simulate "decision" of the computer

// FUNCTION DECLARATIONS

/**
Changes the color of the text to be writen next
@param color: integer corresponding to the color ID
@return (none)
*/
void setColor(unsigned int color);

/**
Displays the current board taking into account the player's turn
@param board: current board
@param score: score of the players
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@param currentMove: if indicated, highlights the seed which is being currently changed (encoded in format: 10 * row + column)
@return (none)
*/
void displayBoard(const short board[][HOLES_PER_ROW], const char score[], short playerTurn, char currentMove = -1);

/**
Reads a valid character from the keyboard, in order to indicate the selected mode
@return character that the user entered (two players: 0, player starts: 1, computer starts: 2)
*/
char readMode();

/**
Reads a valid character from the keyboard
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@return character that the user entered
*/
char readChoice(short playerTurn);

/**
Copies all the elements of an 2x6 array to another one, given as a parameter
@param board: array to be copied
@param board: array that holds the copy
@return (void)
*/
void copyBoard(const short board[][HOLES_PER_ROW], short copy[][HOLES_PER_ROW]);

/**
Checks if a given element given as a parameter is located in the vector
@param elem: element to be found in the vector
@param vetor: vector where the element will be searched
@return boolean indicating if the element given as parameter is in the vector
*/
bool isInVector(short elem, const std::vector<short> vetor);

/**
Checks if the row indicated as a parameter is empty
@param board: current board
@param row: index of the row that will be checked
@param firstIdx: index of the first column that will be checked
@param lastIdx: index of the last column that will be checked
@return boolean indicating if the row indicated as a parameter is empty
*/
bool checkEmptyRow(const short board[][HOLES_PER_ROW], short row, short firstIdx = 0, short lastIdx = HOLES_PER_ROW - 1);

/**
Checks whether the player left the adversary without moves
@param board: current board
@param index: index of the last hole whose seed was placed
@param enemyRow: index of the row in board of the adversary 
@return boolean indicating if the adversary can't play
*/
bool grandSlam(const short board[][HOLES_PER_ROW], short index, const short enemyRow);

/**
Distributes the seeds according to the chosen hole
@param board: current board
@param score: score of the players
@param currentRow: index of the row of the player who is playing this turn
@param currentCol: index of the column of the chosen hole
@param simulation: indicates if this is a simulation (i.e. used by the computer to select the best choice)
@return (none)
*/
void updateBoard(short board[][HOLES_PER_ROW], char score[], short currentRow, short currentCol, bool simulation = false);

/**
Scores the seeds of each side to the respective player when both players agree to end the game
@param board: current board
@param score: score of the players
@return (none)
*/
void friendlyEnd(short board[][HOLES_PER_ROW], char score[]);

/**
Checks possible moves that the player can make to allow the adversary to play
@param board: current board
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@return vector containing the indexes that the player can choose
*/
std::vector<short> allowAdversaryPlay(const short board[][HOLES_PER_ROW], short playerTurn);

/**
Determines the choice that allows a greater score
@param board: current board
@param choices: vector containing the indexes that can be chosen
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@return index of the chosen choice
*/
short bestChoice(const short board[][HOLES_PER_ROW], std::vector<short> choices, short playerTurn);

/**
Manages the current turn
@param board: current board
@param score: score of the players
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@param singlePlayerMode: indicates if the player is playing with other player or with the computer and if that's the case, which player he chose
@return (none)
*/
void playTurn(short board[][HOLES_PER_ROW], char score[], short playerTurn, char singlePlayerMode);

/**
Checks wether the game has ended and, if that's the case, indicates the winner
@param score: score of the players
@return integer which indicates if there are winners (0: no winner, 1: player 1, 2: player 2, 3: draw)
*/
short checkEnd(const char score[]);

/**
Displays a message indicating the result of the game
@param winner: ID indicating the winner (return value from checkEnd function)
@param playerTurn: indicates which player is playing (player 1: 0, player 2: 1)
@return (none)
*/
void displayWinner(short winner, short playerTurn);
#endif