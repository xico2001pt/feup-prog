Projeto Oware
PROG/MIEIC, 2019/20
Francisco Gonçalves Cerqueira (up201905337@fe.up.pt)
1MIEIC07

Objetivo Inicial:
Desenvolver um programa para jogar o jogo Oware.

Regras abordadas:
Em cada turno, o jogador correspondente terá de selecionar de qual casa deseja distribuir as sementes no sentido contrário dos ponteiros do relógio, não podendo escolher uma que esteja vazia, deixando apenas uma semente em cada casa que passa (exceto a casa de onde as sementes foram escolhidas).
O jogador apenas pode coletar as sementes que estão no lado do adversário, com a exceção de que, no caso da jogada realizada ocorrer o Grand Slam (coletar todas as peças do adversário), as sementes são distribuidas normalmente, não havendo a recolha das mesmas.
Existe também a opção de, caso os jogadores observem que o jogo entrou num ciclo, concordarem em terminar este e as sementes restantes serão recolhidas para o jogador do lado correspondente.
Por último, os jogadores são obrigados a fazer jogadas que permitam que o advesário, na ronda seguinte, também tenha a possiblidade de jogar. No caso particular de que não existe qualquer possibilidade de escolher uma casa que permita que o adversário não tenha o seu lado vazio, as sementes são recolhidas da mesma maneira que descrito anteriormente no fim amigável.

Estrutura do programa:
Foram criados um ficheiro main.cpp, que contem a estrutura superficial do programa e a inicialização de variaveis, um ficheiro oware.h, que contem todas a inicialização de todas as funções utilizadas e constantes usadas e um ficheiro oware.cpp, que contem o corpo das funções.
O programa segue uma estrutura modular, sendo este dividido superficialmente em três partes: ínicio da jogada, onde é mostrado o tabuleiro e o jogador introduz a sua escolha; a jogada do turno, onde são verificadas várias componentes, tais como o fim amigável, quais casas permitem ao adversário jogar, a existência de Grand Slam e o processe do atualização do tabuleiro; e finalmente a verificação do término do jogo, anunciando o vencedor em caso positivo ou empate.

Objetivos alcançados:
Todos as funcionalidades foram implementadas, juntamente com um menu inicial, no qual o jogador pode escolher jogar com outro ou contra o computador, escolhendo se quer ser o primeiro a jogar.
No modo "single player", foi abordado o algoritmo de, a partir das possibilidades de escolha (jogadas que permitem ao adversário jogar e casas não vazias), determinar qual decisão irá permitir ao computar acumular mais pontos.

Observações:
É possível verificar a ineficiência e o tamanho exagerado de algum código, pois o projeto foi realizado maioritariamente com os primeiros tópicos abordados na Unidade Curricular.