#include <Windows.h>
#include <iostream>
#include <vector>
#include "oware.h"

using namespace std;

void setColor(unsigned int color) {
	HANDLE hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hcon, color);
}

void displayBoard(const short board[][HOLES_PER_ROW], const char score[], short playerTurn, char currentMove) {
	short oppositePlayer = (playerTurn + 1) % ROWS; // Adversary player number
	system("cls"); // Clear console
	// Draw top of the board
	cout << "\t \tF\t|\tE\t|\tD\t|\tC\t|\tB\t|\tA" << endl;
	cout << "-----------------------------------------------------------------------------------------------------------------" << endl;
	cout << "\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	cout << "\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl << "\t|\t";
	// Adversary pieces (shown by reverse order)
	for (char i = 0; i < HOLES_PER_ROW; i++) {
		setColor(COLORS[oppositePlayer]); // Display the seeds in the corresponding player's color
		// Display the seed in yellow if it's currently being changed
		if (10 * oppositePlayer + HOLES_PER_ROW - (i + 1) == currentMove)
			setColor(YELLOW);
		cout << board[oppositePlayer][HOLES_PER_ROW - (i + 1)];
		setColor(RESET);
		cout << "\t|\t";
	}
	// Draw middle of the board
	cout << "\n\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	cout << "\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	// Players score
	cout << "   ";
	setColor(COLORS[oppositePlayer]); // Display the score in the corresponding player's color
	cout << static_cast<int> (score[oppositePlayer]);
	setColor(RESET);
	cout << "\t|-----------------------------------------------------------------------------------------------|   ";
	setColor(COLORS[playerTurn]); // Display the score in the corresponding player's color
	cout << static_cast<int> (score[playerTurn]);
	setColor(RESET);
	cout << "\n\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	cout << "\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl << "\t|\t";
	// Player pieces
	for (char i = 0; i < HOLES_PER_ROW; i++) {
		setColor(COLORS[playerTurn]);
		if (10 * playerTurn + i == currentMove) // Display the seed in yellow if it's currently being changed
			setColor(YELLOW);
		cout << board[playerTurn][i];
		setColor(RESET);
		cout << "\t|\t";
	}
	// Draw bottom of the board
	cout << "\n\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	cout << "\t|\t \t|\t  \t|\t \t|\t \t|\t \t|\t \t|\t" << endl;
	cout << "-----------------------------------------------------------------------------------------------------------------" << endl;
	cout << "\t \ta\t|\tb\t|\tc\t|\td\t|\te\t|\tf\n" << endl;
}

char readMode() {
	char userInput; // Player character input
	bool validOperation = false; // Boolean indicating if the operation is valid
	cout << "Do you want to:\n0 - Play with a friend\n1 - Play with computer (player starts)\n2 - Play with computer (computer starts)" << endl; // Display menu message
	// Force user to input a valid character
	do {
		cin >> userInput;
		// Check if it's valid
		if (!cin.fail() && cin.peek() == '\n') {
			userInput = tolower(userInput); // Accept upper or lower input
			if (userInput == '0' || userInput == '1' || userInput == '2') // Check if it's a valid character
				validOperation = true;
			else cout << "Invalid input!" << endl;
		}
		else {
			cout << "Invalid input!" << endl;
			cin.clear();
		}
		cin.ignore(100000, '\n'); // Clearn buffer
	} while (!validOperation);
	return (int)userInput - 48; // Return the number as an integer
}

char readChoice(short playerTurn) {
	char userInput; // Player character input
	bool validOperation = false; // Boolean indicating if the operation is valid
	do {
		setColor(COLORS[playerTurn]);
		cout << "Player " << playerTurn + 1 << ": ";
		setColor(RESET);
		cin >> userInput;
		// Check if it's valid
		if (!cin.fail() && cin.peek() == '\n') {
			userInput = tolower(userInput); // Accept upper or lower input
			if (userInput == 'a' || userInput == 'b' || userInput == 'c' || userInput == 'd' || userInput == 'e' || userInput == 'f' || userInput == 'x') // Check if it's a valid character
				validOperation = true;
		}
		else {
			cout << "Invalid input!" << endl;
			cin.clear();
		}
		cin.ignore(100000, '\n'); // Clean buffer
	} while (!validOperation);
	return userInput;
}

void copyBoard(const short board[][HOLES_PER_ROW], short copy[][HOLES_PER_ROW]) {
	for (char row = 0; row < ROWS; row++)
		for (char col = 0; col < HOLES_PER_ROW; col++)
			copy[row][col] = board[row][col]; // Copy the element
}

bool isInVector(short elem, const vector<short> vetor) {
	for (char i = 0; i < vetor.size(); i++)
		if (vetor.at(i) == elem)
			return true; // The element was found
	return false; // The element was not found
}

bool checkEmptyRow(const short board[][HOLES_PER_ROW], short row, short firstIdx, short lastIdx) {
	for (char i = firstIdx; i < lastIdx + 1; i++) {
		if (board[row][i] != 0)
			return false; // The row is not empty
	}
	return true; // The row is empty
}

bool grandSlam(const short board[][HOLES_PER_ROW], short index, const short enemyRow) {
	short value; // Number of seeds in the current hole
	// Check if the player can pick all the holes he passed by
	for (char i = index; i >= 0; i--) {
		value = board[enemyRow][i];
		if (value != 2 && value != 3)
			return false;
	}
	// Check if the following holes are empty
	return checkEmptyRow(board, enemyRow, index + 1);
}

void updateBoard(short board[][HOLES_PER_ROW], char score[], short currentRow, short currentCol, bool simulation) {
	const short INITIAL_ROW = currentRow, INITIAL_COL = currentCol; // Initial position
	// Sowing
	short seeds = board[currentRow][currentCol]; // Number of seeds in the chosen hole
	board[currentRow][currentCol] = 0; // Empty the chosen hole
	while (seeds > 0) {
		currentCol++; // Next hole
		if (currentCol >= HOLES_PER_ROW) {
			currentCol = 0; // Start from first col
			currentRow = (currentRow + 1) % ROWS; // Change row
		}
		if (currentCol != INITIAL_COL || currentRow != INITIAL_ROW) {
			board[currentRow][currentCol] = board[currentRow][currentCol] + 1; // Increase one seed in the hole
			seeds--; // Decreases one seed in the seeds left
			if (!simulation) { // If is not a simulation so the computer can choose the best case
				displayBoard(board, score, INITIAL_ROW, 10 * currentRow + currentCol); // Display the board in console
				Sleep(MOVE_SEED_TIME); // Simulates the time to move a seed
			}
		}
	}
	// Capturing
	const short ENEMY_ROW = (INITIAL_ROW + 1) % ROWS;
	if (currentRow == ENEMY_ROW && !grandSlam(board, currentCol, ENEMY_ROW)) {
		short value; // Number of seeds in the current hole
		// Score every hole the player passed by
		for (char i = currentCol; i >= 0; i--) {
			value = board[ENEMY_ROW][i];
			if (value == 3 || value == 2) {
				score[INITIAL_ROW] += board[ENEMY_ROW][i]; //Adding the seeds to score
				board[ENEMY_ROW][i] = 0; // Removing the seeds
				if (!simulation) { // If is not the computer choosing the best case
					displayBoard(board, score, INITIAL_ROW, 10 * currentRow + i); // Display the board in console
					Sleep(MOVE_SEED_TIME); // Simulates the time to move a seed
				}
			}
			else
				break;
		}
	}
}

void friendlyEnd(short board[][HOLES_PER_ROW], char score[]) {
	for (char player = 0; player < ROWS; player++)
		for (char index = 0; index < HOLES_PER_ROW; index++) {
			score[player] += board[player][index]; // Collect seeds for the corresponding player
			board[player][index] = 0; // Empty the chosen hole
		}
}

vector<short> allowAdversaryPlay(const short board[][HOLES_PER_ROW], short playerTurn) {
	vector<short> possibleChoices = {}; // Vector that will be returned, containing the possible choices
	short oppositePlayer = (playerTurn + 1) % ROWS; // Adversary player number
	short backupBoard[ROWS][HOLES_PER_ROW]; // Empty copy of the original board
	char fakeScore[ROWS] = { 0,0 }; // Score array
	// Brute force every single possibility
	for (short userIndex = 0; userIndex < HOLES_PER_ROW; userIndex++) {
		if (board[playerTurn][userIndex] != 0) { // If the hole sin't empty
			copyBoard(board, backupBoard); // Reset the backup board
			updateBoard(backupBoard, fakeScore, playerTurn, userIndex, true); // Distributing the seeds
			if (!checkEmptyRow(backupBoard, oppositePlayer)) // If the adversary will be able to play
				possibleChoices.push_back(userIndex); // Add this choice to the vector of possible choices
		}
	}
	return possibleChoices;
}

short bestChoice(const short board[][HOLES_PER_ROW], vector<short> choices, short playerTurn) {
	short backupBoard[ROWS][HOLES_PER_ROW]; // Empty copy of the original board
	char fakeScore[ROWS] = { 0,0 }; // Score array
	char highestScore = 0; // Holds the highest score
	short bestOption = choices.at(0); // Holds the best option
	char value; // Current value of the score
	// Brute force every single possibility
	for (short i = 0; i < choices.size(); i++) {
		fakeScore[playerTurn] = 0; // Reset player's score
		copyBoard(board, backupBoard); // Reset the backup board
		updateBoard(backupBoard, fakeScore, playerTurn, choices.at(i), true); // Distributing the seeds
		value = fakeScore[playerTurn]; // Adds the simulated score to the array
		// Find the highest score
		if (value > highestScore || (value == highestScore && !(rand() % (i + 1)))) { // Note: If the value is the same as the highest, there's a chance of changing it
			highestScore = value; // Value is now the highest score
			bestOption = choices.at(i); //  Update the best option
		}
	}
	return bestOption;
}

void playTurn(short board[][HOLES_PER_ROW], char score[], short playerTurn, char singlePlayerMode) {
	short oppositePlayer = (playerTurn + 1) % ROWS; // Adversary player number
	bool validMove = false; // Determines if the player has made a valid choice
	short holeIndex; // Index in the array of the player choice
	char userInput; // Player character input
	vector<short> choices = allowAdversaryPlay(board, playerTurn); // Possible moves the player can make to allow the adversary to play
	if (choices.size()) { // If there are choices
		if (singlePlayerMode == 0 || singlePlayerMode - 1 == playerTurn) { // If it's player vs player or it's player's turn in singleplayer
			do {
				userInput = readChoice(playerTurn);
				if (userInput == 'x') {
					friendlyEnd(board, score);
					validMove = true;
				}
				else {
					holeIndex = (int)userInput - 97; // Convert the character to the corresponding index using ASCII
					// Check if the hole has no seeds
					if (board[playerTurn][holeIndex] == 0)
						cout << "Invalid move!" << endl;
					else if (!isInVector(holeIndex, choices))
						cout << "You have to allow your adversary to play!" << endl;
					else {
						updateBoard(board, score, playerTurn, holeIndex); // Update the board according to the choice
						validMove = true;
					}
				}
			} while (!validMove);
		}
		else { // If it's player vs computer and it's computer's turn
			// Simulate "decision" of the computer
			setColor(COLORS[playerTurn]);
			cout << "Player " << playerTurn + 1 << ": ";
			setColor(RESET);
			cout << "Thinking";
			for (char i = 0; i < 3; i++) {
				cout << ". ";
				Sleep(DECISION_TIME / 3); // Simulates the time to decide the move
			}
			holeIndex = bestChoice(board, choices, playerTurn); // Determine the best choice
			cout << "\b\b\b\b\b\b\b\b\b\b\b\b\b\b" << (char)(97 + holeIndex) << "             \b\b\b\b\b\b\b\b\b\b\b\b\b"; // Delete "Thinking" message and print choice
			Sleep(DECISION_TIME / 2); // Simulates the time to move a seed
			updateBoard(board, score, playerTurn, holeIndex); // Update the board according to the choice
		}
	}
	else {
		setColor(COLORS[oppositePlayer]);
		cout << "Player " << oppositePlayer + 1;
		setColor(RESET);
		cout << " won't be able to make a move! All the seeds will be captured!" << endl;
		getchar(); // Wait for the user to end the program
		friendlyEnd(board, score);
	}
}

short checkEnd(const char score[]) {
	if (score[0] > 24) return 1; // Player 1 wins
	else if (score[1] > 24) return 2; // Player 2 wins
	else if (score[0] == 24 && score[1] == 24) return 3; // It's a draw
	return 0; // The game isn't over
}

void displayWinner(short winner, short playerTurn) {
	if (winner == 3) // Draw
		cout << "The game ended in a draw!" << endl;
	else // Winner
		setColor(COLORS[playerTurn]);
	cout << "Player " << winner;
	setColor(RESET);
	cout << " won the game!" << endl;
	getchar(); // Wait for the user to end the program
}