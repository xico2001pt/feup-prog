#include <iostream>
#include <ctime>
#include "oware.h"

int main() {
	srand((unsigned)time(NULL)); // Ensure random number

	short board[ROWS][HOLES_PER_ROW] = { 4,4,4,4,4,4,4,4,4,4,4,4 }; // Initial board array
	char score[ROWS] = { 0,0 }; // Initial score array
	short currentPlayer = 1; // Stores the number of the player that is currently playing
	short gameOver; // Indicates if the game is over and who is the winner
	char singlePlayerMode; // Indicates if the player is playing with other player or with the computer and if that's the case, which player he chose
	singlePlayerMode = readMode();
	do {
		currentPlayer = (currentPlayer + 1) % ROWS; // Change turn to the next player
		displayBoard(board, score, currentPlayer); // Display the board in console
		playTurn(board, score, currentPlayer, singlePlayerMode); // Allows player to play
		gameOver = checkEnd(score);
	} while (!gameOver);
	displayBoard(board, score, currentPlayer); // Display the board in console in the prespective of the winner
	displayWinner(gameOver, currentPlayer); // Winner announcement
	return 0;
}